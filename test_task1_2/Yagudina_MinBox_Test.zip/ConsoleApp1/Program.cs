﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape[] shapes = new Shape[] { new Circle(10), new Triangle(3, 11, 10)};

            foreach(var item in shapes)
            {
                Console.WriteLine(item.Name());
            }
        }
    }
}
