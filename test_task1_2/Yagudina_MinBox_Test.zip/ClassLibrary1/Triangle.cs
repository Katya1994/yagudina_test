﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public enum TrianleType { Ordinary, Rectangular}

    public class Triangle : Shape
    {
        public double FirstSide { get; private set; }
        public double SecondSide { get; private set; }
        public double ThirdSide { get; private set; }
        public TrianleType Type { get; private set; }

        public Triangle(double firstSide, double secondSide, double thirdSide)
        {
            if (firstSide + secondSide <= thirdSide || firstSide + thirdSide <= secondSide || secondSide + thirdSide <= firstSide)
                throw new ArgumentException("Треугольника с такими сторонами не может существовать!");
            else
            {
                FirstSide = firstSide;
                SecondSide = secondSide;
                ThirdSide = thirdSide;

                List<double> sides = new List<double>() { firstSide, secondSide, thirdSide }.OrderByDescending(s => s).ToList();
                if (sides[0] * sides[0] == sides[1] * sides[1] + sides[2] * sides[2])
                {
                    Type = TrianleType.Rectangular;
                }
                else
                    Type = TrianleType.Ordinary;
            }
        }

        public override double Area()
        {
            double semiperimeter = Perimeter() / 2;
            return Math.Sqrt(semiperimeter * (semiperimeter - FirstSide) * (semiperimeter - SecondSide) * (semiperimeter - ThirdSide));
        }

        public override double Perimeter() => FirstSide + SecondSide + ThirdSide;

        public override string Name() => "Triangle";     
    }
}
